import random

# Define a dictionary mapping each special character to a tuple of the form (min_val, max_val)
special_chars = {
    "@": (0, 500),  #   @ = 0-500 Bulk
    "*": (25, 500), #   * = 25-500 Ammo
    "&": (10, 500), #   & = 10-500 Damage 
    "`": (25, 800), #   ` = 25-800 Jump vert
    "$": (25, 400), #   $ = 25-400 move grav
    "!": (50, 300), #   ! = 50-300 move speed
    "#": (0, 300),  #   # = 0-300 for ashe maybe other
    "?": (0, 400),  #   ? = 0-400 some Scalars
    "+": (0, 200),  #   + = 0-200 for dva
    "~": (33, 500), #   ~ = 33-500 Dooooooom fist
    "=": (3, 12),   #   = = 3-12 has no ball's arrows
    "|": (25, 300), #   | = 25-300 Lady torb + Pharah
    "^": (40, 400), #   ^ = 40-400 Junker Queen Blade?
    "_": (0, 100),  #   _ = 0-100 for mei 
    ">": (20, 200), #   > = 20-200 life grip bloss range
    "<": (50, 300),  #   < = 50-300 tree of life
    "'": (20, 500)  #   ' = 20-500 Pharah max hover time
}
# Open the input file for reading
with open("base.txt", "r") as input_file:
    # Read the contents of the file into a string
    input_text = input_file.read()

# Split the input text into a list of lines
lines = input_text.splitlines()

# Loop through each line in the list
for i in range(len(lines)):
    # Check if the line contains any special characters
    if any(char in lines[i] for char in special_chars.keys()):
        # Split the line into a list of words
        words = lines[i].split()
        # Loop through each word in the list
        for j in range(len(words)):
            # Check if the word contains a special character
            if any(char in words[j] for char in special_chars.keys()):
                # Iterate through the dictionary to find the special character and its range
                for char, (min_val, max_val) in special_chars.items():
                    # If the special character is found, replace it with a random value within its range
                    if char in words[j]:
                        random_number = random.randint(min_val, max_val)
                        words[j] = words[j].replace(char, str(random_number))
                        break  # Break out of the loop once the character has been replaced
        # Join the modified list of words back into a string and overwrite the original line in the lines list
        lines[i] = " ".join(words)

# Join the modified list of lines back into a string and write it to an output file
with open("Randomized.txt", "w") as output_file:
    output_file.write("\n".join(lines))
